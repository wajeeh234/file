// Write a list of strings to a 'file' (simulated by returning the string data)
String writeToFile(List<String> data) {
  try {
    final content = data.join('\n');
    return content;
  } catch (e) {
    print("An error occurred while writing to the file: $e");
    return '';
  }
}

// Read the contents of a 'file' (simulated by accepting a string as input)
List<String> readFromFile(String content) {
  try {
    return content.split('\n');
  } catch (e) {
    print("An error occurred while reading the file: $e");
    return [];
  }
}

// Process the file data: read from input 'file', reverse each line, and return the output 'file' content
String processFileData(String inputContent) {
  final data = readFromFile(inputContent);
  final reversedData =
      data.map((line) => line.split('').reversed.join()).toList();
  return writeToFile(reversedData);
}

// Testing
void main() {
  final data = [
    'Hello, World!',
    'Flutter is awesome.',
    'Modular code is great.'
  ];

  // Simulate writing to a file by getting the content string
  final inputFileContent = writeToFile(data);
  print('Input file content:');
  print(inputFileContent);

  // Simulate processing the file content
  final outputFileContent = processFileData(inputFileContent);
  print('\nProcessed file content:');
  print(outputFileContent);
}
